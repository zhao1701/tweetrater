$(document).ready(function() {
	//$('.flash a').hide().fadeIn(5000);
	$('.summary').hide().fadeIn(2000);
	$('tr').hide().delay(500).fadeIn(4000);
	// $('table').hide().show('drop', {direction: 'left'}, 3000);
	$('table').hide().show(3000);
});